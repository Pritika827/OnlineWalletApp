package org.cap.dao;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.cap.model.TransactionType;


public class UserDaoImpl implements IUserDao{

	/*entity manager implements the API and encapsulates all of them within a single interface.*/
	private EntityManager getEntityManager() {
		EntityManagerFactory entityManagerFactory=
				Persistence.createEntityManagerFactory("capg");

		return entityManagerFactory.createEntityManager();
	}

	/*-----------------------------------------LOGIN----------------------------------------*/
	@Override
	public Customer validateLogin(Customer customer) {

		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction= entityManager.getTransaction();
		entityTransaction.begin();

		Query query= entityManager.createQuery("from Customer c where c.emailId=:uname and "
				+ " c.password=:upwd");
		query.setParameter("uname", customer.getEmailId());
		query.setParameter("upwd", customer.getPassword());

		List<Customer> users =query.getResultList();
		if(!users.isEmpty())
			return users.get(0);
		entityTransaction.commit();
		entityManager.close();
		return null;
	}



	/*-----------------------------Register customer in wallet-------------------------------*/

	@Override
	public Customer registerCustomer(Customer customer, Address address) {
		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();

		entityManager.persist(customer); //generate customer ID pk & save customer record
		address.setCustomer(customer);
		entityManager.persist(address);

		entityTransaction.commit();
		entityManager.close();
		return customer;
	}


	/*------------------------Register customer Create account----------------------*/
	@Override
	public Account createAccount(Account account) {
		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();

		Customer customer=entityManager.find(Customer.class, account.getCustomer().getCustomerId());
		account.setCustomer(customer);

		entityManager.persist(account);			
		entityTransaction.commit();

		entityManager.close();
		return account;
	}



	/*------------find customer data by primary key customerId----------------------*/
	@Override
	public Customer findCustomer(int customerId) {
		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();

		Customer customer=entityManager.find(Customer.class, customerId);
		if(customer!=null)
			return customer;
		entityTransaction.commit();
		entityManager.close();
		return null;
	}

	/*------------------------find customer account---------------------------------*/	
	@Override
	public List<Account> findAccountsByCustomer(Customer customer, String str) {
		EntityManager entityManager = getEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		Query query;
		if (str.equalsIgnoreCase("from")) {
			query = entityManager.createQuery("from Account a where a.customer=:customer");
		} else {
			query = entityManager.createQuery("from Account a where a.customer!=:customer");
		}
		query.setParameter("customer", customer);
		List<Account> accounts = query.getResultList();
		if (!accounts.isEmpty())
			return accounts;
		entityTransaction.commit();
		entityManager.close();
		return null;
	}

	/*--------------------------find account----------------------------*/
	@Override
	public Account findAccount(int accountno) {
		EntityManager entityManager = getEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();

		Account account = entityManager.find(Account.class, accountno);

		entityTransaction.commit();
		entityManager.close();
		return account;
	}




	/*----------------------save trasaction in table -------------------------------*/
	@Override
	public Account transaction(int accountno, double amount, String transactiontype) {
		EntityManager entityManager = getEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		Account account = entityManager.find(Account.class, accountno);
		if (transactiontype.equalsIgnoreCase("deposit")) {
			//account.setBalance(account.getBalance() + amount);
			String sql1 = "update Account set balance=balance+" +amount+ " where accountNumber="+accountno;
			Query query1 = entityManager.createQuery(sql1);
			query1.executeUpdate();
			account.setAccountNumber(accountno);
			Transaction transaction = new Transaction(LocalDate.now(),amount,TransactionType.CREDIT,account);
			entityManager.persist(transaction);


		} else {
			String sql1 = "update Account set balance=balance-" +amount+ " where accountNumber="+accountno;
			Query query1 = entityManager.createQuery(sql1);
			query1.executeUpdate();
			account.setBalance(account.getBalance() - amount);
			account.setAccountNumber(accountno);
			Transaction transaction = new Transaction(LocalDate.now(),amount,TransactionType.DEBIT,account);
			entityManager.persist(transaction);

		}	
		entityTransaction.commit();
		entityManager.close();
		return account;
	}

	/*---------------show transaction according to date and account type----------------------*/
	@Override
	public List<Transaction> allTransactionShow(int accountno, String start_date, String end_date) {
		EntityManager entityManager = getEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();

		entityTransaction.begin();

		String sql="from Transaction where account_fk="+accountno+" and transactionDate between '"+start_date+" ' and  '"+end_date+" '";
		Query query =entityManager.createQuery(sql);
		List<Transaction> Transactionlist = query.getResultList();

		if (!Transactionlist.isEmpty())
			return Transactionlist;

		entityTransaction.commit();
		entityManager.close();
		return null;		
	}

/*-----------------------show transaction according to account type----------------*/
	@Override
	public List<Transaction> transactionshow(int accountno) {
		EntityManager entityManager = getEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();

		entityTransaction.begin();

		String sql="from Transaction where account_fk="+accountno+"";
		Query query =entityManager.createQuery(sql);
		List<Transaction> Transactionlist = query.getResultList();

		if (!Transactionlist.isEmpty())
			return Transactionlist;

		entityTransaction.commit();
		entityManager.close();
		return null;		
	}



}