package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.AccountType;
import org.cap.model.Customer;
import org.cap.service.IUserService;
import org.cap.service.UserServiceImpl;


@WebServlet("/CreateAccServlet")
public class CreateAccServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private IUserService userService;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		userService = new UserServiceImpl();

		HttpSession httpSession = request.getSession(true);
		int customerId = Integer.parseInt(httpSession.getAttribute("customerId").toString()) ;
		Account account= new Account();

		String accountType = request.getParameter("accountType");

		//		SAVING,CURRENT,LOAN,SALARY
		
		if(accountType.equalsIgnoreCase("SAVING")) 
			account.setAccountType(AccountType.SAVINGS);
		else if(accountType.equalsIgnoreCase("CURRENT"))
			account.setAccountType(AccountType.CURRENT);
		else if(accountType.equalsIgnoreCase("LOAN"))
			account.setAccountType(AccountType.LOAN);
		else
			account.setAccountType(AccountType.SALARY);

		double balance = Double.parseDouble(request.getParameter("balance"));
		account.setBalance(balance);

		String desciption = request.getParameter("description");
		account.setDescription(desciption);

		Customer customer = userService.findCustomer(customerId);

		account.setCustomer(customer);

		Account account2= userService.createAccount(account);
		PrintWriter out=response.getWriter();
		
		if(account2!=null) {
	//		out.println("<div style='color:red;'>Account created Successfully !! </div>");
//						out.println(""
//								+ "<html>"
//								+ "<body>"
//								+ "<script>"
//								+ "alert('Account created Successfully !!')"
//								+ "</script>"
//								+ "</body>"
//								+ "</html>");
		//	request.getRequestDispatcher("MainPageServlet").include(request, response);	
			response.sendRedirect("MainPageServlet");
		}		
	}

}
