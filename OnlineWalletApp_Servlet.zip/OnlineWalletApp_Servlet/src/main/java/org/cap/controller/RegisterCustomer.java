package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.service.IUserService;
import org.cap.service.UserServiceImpl;

@WebServlet("/RegisterCustomer")
public class RegisterCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private IUserService userService;
       
    public RegisterCustomer() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		userService=new UserServiceImpl();
		
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String contactNo=request.getParameter("contactNo");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		String gender=request.getParameter("gender");
		Customer customer=new Customer(firstName, lastName, contactNo, gender, email,  password);	
		String addressline1=request.getParameter("addressline1");
		String addressline2=request.getParameter("addressline2");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String pincode=request.getParameter("pincode");
		Address address=new Address(addressline1, addressline2, city, state, pincode,customer);

		
		Customer customer2= userService.registerCustomer(customer, address);
		PrintWriter printWriter = response.getWriter();
		if(customer2.getCustomerId() > 0)
			//out.println("<div style='color:red;'>Account created Successfully! </div>");
			printWriter.println(""
					+ "<html>"
					+ "<body>"
					+ "<script>"
					+ "alert('Account created Successfully !!')"
					+ "</script>"
					+ "</body>"
					+ "</html>");
			response.sendRedirect("index.html");
		
		
	}

}
