package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.model.Transaction;
import org.cap.service.IUserService;
import org.cap.service.UserServiceImpl;


@WebServlet("/TransactionListServlet1")
public class TransactionListServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private IUserService userService;

	public TransactionListServlet1() {
		super();
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		userService = new UserServiceImpl();

		HttpSession httpSession = request.getSession(true);
		int customerId1 = (int) httpSession.getAttribute("customerId");
		int customerId = Integer.parseInt(httpSession.getAttribute("customerId").toString()) ;
		String customerName=httpSession.getAttribute("customerName").toString();

		int accountno = Integer.parseInt(request.getParameter("account"));

		List <Transaction> Transaction_List =userService.transactionshow(accountno);

		PrintWriter printWriter = response.getWriter();
		printWriter.println("<!DOCTYPE html>\r\n"
				+ "<html lang=\"en\">\r\n"
				+ "<head>\r\n"
				+ "<title>Transaction list</title>\r\n"
				+ "<meta charset=\"utf-8\">\r\n"
				+ "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n"
				+ "<link\r\n"
				+ "	href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css\"\r\n"
				+ "	rel=\"stylesheet\"\r\n"
				+ "	integrity=\"sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3\"\r\n"
				+ "	crossorigin=\"anonymous\" />\r\n"

		//		+ "<script type=\"text/javascript\" src=\"../script/createAcc.js\"></script>\r\n"

				+ "</head>\r\n"
				+ "<body>\r\n"
				+ "	<section class=\"vh-100\" style=\"background-color: #0FAE2F;\">\r\n"
				+ "		<div class=\"container\">\r\n"
				+ "			<h3 class=\"fw-normal display-6 mb-2 pb-6 mt-1\"\r\n"
				+ "				style=\"letter-spacing: 1px; text-align: center; font-family: Algerian;\">Online\r\n"
				+ "				Wallet Application</h3>\r\n"
				+ "		</div>\r\n"
				+ "\r\n"
				+ "		<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">\r\n"
				+ "			<div class=\"container-fluid\">\r\n"
				+ "\r\n"
				+ "				<button class=\"navbar-toggler\" type=\"button\"\r\n"
				+ "					data-bs-toggle=\"collapse\" data-bs-target=\"#navbarSupportedContent\"\r\n"
				+ "					aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\"\r\n"
				+ "					aria-label=\"Toggle navigation\">\r\n"
				+ "					<span class=\"navbar-toggler-icon\"></span>\r\n"
				+ "				</button>\r\n"
				+ "				<div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">\r\n"
				+ "					<ul class=\"navbar-nav me-auto mb-2 mb-lg-0\">\r\n"
				+ "						<li class=\"nav-item\"><a class=\"nav-link active\"\r\n"
				+ "							aria-current=\"page\" href='MainPageServlet'>Home</a></li>\r\n"
				+ "						<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "							href=\"CreateAccount\">create account</a></li>\r\n"
				+ "							\r\n"
				+ "							<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "							href='AccountDetail'>account detail</a></li>\r\n"

				+ "						<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "							href='DepositServlet'>deposite/withdraw</a></li>\r\n"
				+ "							\r\n"
				+ "							<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "							href='FundTransferServlet1'>fund transfer</a></li>\r\n"

				+ "							<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "							href='TransactionServletPage'>transaction search</a></li>\r\n"

				+ "							<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "							href='TransactionServletPage1'>transaction history</a></li>\r\n"


				+ "					</ul>\r\n"
				+ "\r\n"
				+ "					<a class=\"btn btn-outline-success ml-2\" href='LogoutServlet'>logout</a>\r\n"
				+ "\r\n"
				+ "				</div>\r\n"
				+ "			</div>\r\n"
				+ "		</nav>\r\n"
				+ "		<p class=\"mx-4\" align=\"right\">Welcome "+customerName+"</p>\r\n"
				+ ""
				+"<div class=\"container py-2 h-80\">\r\n"
				+ "\r\n"
				+ "			<div\r\n"
				+ "				class=\"row d-flex justify-content-center align-items-center h-100\">\r\n"
				+ "				<div class=\"col col-xl-9\">\r\n"
				+ "					<div class=\"card\" style=\"border-radius: 1rem;\">\r\n"
				+ "						<div class=\"row g-0\">\r\n"
				+ "\r\n"
				+ "\r\n"
				+ "							<div class=\"card-body p-4 p-lg-4 text-black\">\r\n"
				+ ""	
				+ "								<table id=\"example\" class=\"table table-striped\">"
				+ "									<h4 class=\"card-title\">Transaction history</h4>\r\n"

				+ "										 <tr>"
				+ "												<th>Transaction ID</th>\r\n"
				+ "											 	<th>Transaction Amount</th>\r\n"
				+ "											 	<th>Transaction Date</th>\r\n"
				+ "											 	<th>Transaction Type</th>\r\n"
				+ "											 	<th>Account Number</th>"
				+ "											 	<th>Account Type</th>"
				+ "										</tr>"
				);
		for(Transaction account11:Transaction_List) {
			printWriter.println(""
					+ "			<tr>"
					+ "			<td>"+account11.getTransactionId()+"</td>"
					+ "			<td>"+account11.getTransactionAmount()+"</td>"
					+ "			<td>"+account11.getTransactionDate()+"</td>"
					+ "			<td>"+account11.getTransactionType()+"</td>"
					+ "			<td>"+account11.getAccount().getAccountNumber()+"</td>"
					+ "			<td>"+account11.getAccount().getAccountType()+"</td>"
					+ "			</tr>");
		}
		printWriter.println(""
				+ "</table>"
				+ "						</div>\r\n"
				+ "					</div>\r\n"
				+ "				</div>\r\n"
				+ "\r\n"
				+ "\r\n"


						+ "</body>\r\n"
						+ "</html>");

	}

}
