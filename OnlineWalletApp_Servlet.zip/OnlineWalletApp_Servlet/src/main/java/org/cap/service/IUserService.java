package org.cap.service;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.model.Transaction;


public interface IUserService {
	
	public Customer validateLogin(Customer customer);

	public Customer registerCustomer(Customer customer,Address address);
	
	public Account createAccount(Account account);

	
	public Customer findCustomer(int customerId);

	public List<Account> finAccountsByCustomer(Customer customer, String str);
	
	public Account findAccount(int accountno);
	
	
	
	public Account transaction(int accountno, double amount, String transactiontype);
	
	public List<Transaction> allTransactionShow(int accountno, String start_date, String end_date);
		
	public List<Transaction> transactionshow(int accountno);

}
