package org.cap.model;


/*----------------------------constant data-------------------------------------------*/

public enum TransactionType {
	DEBIT,CREDIT
}
