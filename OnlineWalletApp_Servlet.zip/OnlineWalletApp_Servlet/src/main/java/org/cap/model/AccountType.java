package org.cap.model;


/*----------------------------constant data---------------------------------------*/

public enum AccountType {
	SAVINGS,
	CURRENT,
	LOAN,
	SALARY
}
