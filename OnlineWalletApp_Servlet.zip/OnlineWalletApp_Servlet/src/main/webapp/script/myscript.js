function registerFormValidation(){
	
	var firstName= register.firstName.value
	var contactno=register.contactNo.value
	var email=register.email.value
	var addressline1=register.addressline1.value
	var pincode=register.pincode.value
	var password=register.password.value
	var cfmpassword=register.cfmpassword.value
	
	if(firstName=="" || firstName==null ){
		
		document.getElementById("errFirstName").innerHTML='Please enter FirstName!'
		register.firstName.focus()
		return false
		}
		else{
			document.getElementById("errFirstName").innerHTML=''
		}		
		
				
		if(contactno==""  || contactno.length!=10){
		document.getElementById("errcontactNo").innerHTML='Please enter 10 digits!'
		register.contactNo.focus()
		return false
		}
		else{
			document.getElementById("errcontactNo").innerHTML=''
		}
		
		if(!ValidateEmail(email)){
		document.getElementById("erreEmail").innerHTML='Please enter valid email!'
		register.email.focus()
		return false
		}
		else{
			document.getElementById("erreEmail").innerHTML=''
		}
		
		if(addressline1=="" || addressline1==null ){
		
		document.getElementById("errAddr").innerHTML='Please enter address line 1!'
		register.addressline1.focus()
		return false
		}
		else{
			document.getElementById("errAddr").innerHTML=''
		}
		
		if(pincode=="" || pincode==null ){
		
		document.getElementById("errPincode").innerHTML='Please enter pincode!'
		register.pincode.focus()
		return false
		}
		else{
			document.getElementById("errPincode").innerHTML=''
		}
		
		if(password=="" || password==null ){
		
		document.getElementById("errPwd").innerHTML='Please enter password!'
		register.password.focus()
		return false
		}
		else{
			document.getElementById("errPwd").innerHTML=''
		}
		
		if(cfmpassword=="" || cfmpassword==null ){
		
		document.getElementById("errCfmPwd").innerHTML='Please enter password!'
		register.cfmpassword.focus()
		return false
		}
		else{
			document.getElementById("errCfmPwd").innerHTML=''
		}
		
		if(password!=cfmpassword)
		{
			alert("enter password and confirm password same")
			return false
		}	
		
	return true
}




function ValidateEmail(mail) 
{
 if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail))
  {
    return true
  }
  
    return false
}



function myfunc(){
	
	var userName=f1.userName.value
	var userPassword=f1.userPwd.value
	
	if(userName=="" || userName==null ){
		//alert('Please enter userName!')
		document.getElementById("userErrMsg").innerHTML='Please enter email-id!'
		f1.userName.focus()
		return false
		}
		else{
			document.getElementById("userErrMsg").innerHTML=''
		}
	if(userPassword=="" || userPassword==null){
		//alert('Please enter userPassword!')
		document.getElementById("userPwdErrMsg").innerHTML='Please enter userPassword!'
		f1.userPwd.focus()
		return false
		}else{
			document.getElementById("userPwdErrMsg").innerHTML=''
		}
	
	return true
}



	
	
