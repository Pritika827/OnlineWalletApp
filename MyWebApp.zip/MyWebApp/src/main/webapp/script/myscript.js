/**
 * 
 */
function validationLogin(){
var username=f1.userName.value;
if(username==null || username=="")
{
document.getElementById("errUser").innerHTML="Please enter userName."
return false;
}
return true;
}

