package org.cap.demo.model;

public class Register {
	private String firstName;
	private String lastName;
	private String address; 
	private String city;
	private String state;
	private String emailId;
	private String passWord;
	private String gender;
	
	private String pinCode;
	private String contactNo;
	
	public Register() {
		// TODO Auto-generated constructor stub
	}

	public Register(String firstName, String lastName, String address, String city, String state, String emailId,
			String passWord, String gender, String pinCode, String contactNo) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.city = city;
		this.state = state;
		this.emailId = emailId;
		this.passWord = passWord;
		this.gender = gender;
		this.pinCode = pinCode;
		this.contactNo = contactNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	@Override
	public String toString() {
		return "Register [firstName=" + firstName + ", lastName=" + lastName + ", address=" + address + ", city=" + city
				+ ", state=" + state + ", emailId=" + emailId + ", passWord=" + passWord + ", gender=" + gender
				+ ", pinCode=" + pinCode + ", contactNo=" + contactNo + "]";
	}
	
}
