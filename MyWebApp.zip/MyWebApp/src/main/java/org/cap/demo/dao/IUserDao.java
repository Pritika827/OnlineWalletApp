package org.cap.demo.dao;

import org.cap.demo.model.Register;
import org.cap.demo.model.User;

public interface IUserDao {
	public boolean validateLogin(User user);
	public String register(Register register);
}
