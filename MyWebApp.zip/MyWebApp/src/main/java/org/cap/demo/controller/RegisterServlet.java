package org.cap.demo.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.demo.dao.IUserDaoImpl;
import org.cap.demo.model.Register;
import org.cap.demo.model.User;
import org.cap.demo.service.IUserServiceImpl;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public RegisterServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String address=request.getParameter("address"); 
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String emailId=request.getParameter("emailid");
		String passWord=request.getParameter("password");
		String gender=request.getParameter("gender");		
		String pinCode=request.getParameter("pinCode");
		String contactNo=request.getParameter("ContactNo");
		
		Register register= new Register();
		register.setFirstName(firstName);
		register.setLastName(lastName);
		register.setAddress(address);
		register.setCity(city);
		register.setState(state);
		register.setEmailId(emailId);
		register.setGender(gender);
		register.setPinCode(pinCode);
		register.setContactNo(contactNo);
		
		//IUserDaoImpl iUserDaoImpl = new IUserDaoImpl();
		IUserServiceImpl iUserServiceImpl = new IUserServiceImpl();
		User user = new User();
		 String userRegistered = iUserServiceImpl.register(register);
		
		 if(userRegistered.equals("SUCCESS"))  
		   {
		   request.getRequestDispatcher("/sucess.html").forward(request, response);
		   }
		   else   //On Failure, display a meaningful message to the User.
		   {
		   request.setAttribute("errMessage", userRegistered);
		   request.getRequestDispatcher("/register.html").forward(request, response);
		   }
		
	}

}
