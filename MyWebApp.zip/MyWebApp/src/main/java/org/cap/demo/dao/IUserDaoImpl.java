package org.cap.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.cap.demo.model.Register;
import org.cap.demo.model.User;

public class IUserDaoImpl implements IUserDao{

	@Override
	public boolean validateLogin(User user) {
		
		try(Connection connection=getMySqlConnection()){
			String sql="select * from user where username=? and userpassword=?";
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, user.getUserName());
			preparedStatement.setString(2, user.getUserPassword());
			
			ResultSet resultSet= preparedStatement.executeQuery();
			
			if(resultSet.next())
				return true;
			
		}catch (Exception e) {
			e.printStackTrace();
		}	
		return false;
	}
		
	@Override
	public String register(Register register) {
		try(
			Connection connection=getMySqlConnection()){
			String sql="insert into register values(?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps=connection.prepareStatement(sql);
			ps.setString(1, register.getFirstName());
			ps.setString(2,register.getLastName());
			ps.setString(3, register.getAddress());
			ps.setString(4, register.getCity());
			ps.setString(5, register.getState());
			ps.setString(6, register.getPinCode());
			ps.setString(7, register.getEmailId());
			ps.setString(8, register.getContactNo());
			ps.setString(9, register.getPassWord());
			ps.setString(10, register.getGender());
			
			int i= ps.executeUpdate();
			 if (i!=0) 
				    return "SUCCESS"; 
			
		}catch (Exception e) {
			e.printStackTrace();
		}	
		return "Oops.. Something went wrong there..!"; 
	}
	
	private Connection getMySqlConnection() {			
		try
			{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection	connection=
			DriverManager.getConnection("jdbc:mysql://localhost:3306/demo", "root", "Pri123tik@");
			
				return connection;
			
		}catch (Exception e) {
			e.printStackTrace();
		}		
		return null;
	}

}
