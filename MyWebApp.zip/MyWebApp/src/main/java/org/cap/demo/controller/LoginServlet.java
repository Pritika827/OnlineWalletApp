package org.cap.demo.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.demo.model.User;
import org.cap.demo.service.IUserService;
import org.cap.demo.service.IUserServiceImpl;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
private IUserService userService;
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String userName = request.getParameter("userName");
		String userPwd = request.getParameter("userPwd");
		userService = new IUserServiceImpl();
		//model object
		User user = new User(userName, userPwd);
		
		//if(userName.equals("tom") && userPwd.equals("tom123"))
		if (userService.validateLogin(user))
			response.sendRedirect("pages/success.html");
		else
			response.sendRedirect("./");
	}

}
