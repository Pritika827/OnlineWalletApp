package org.cap.demo.service;

import org.cap.demo.dao.IUserDao;
import org.cap.demo.dao.IUserDaoImpl;
import org.cap.demo.model.Register;
import org.cap.demo.model.User;

public class IUserServiceImpl implements IUserService{

	private IUserDao userDao;
	
	public IUserServiceImpl() {
		userDao=new IUserDaoImpl();
	}
	@Override
	public boolean validateLogin(User user) {
		
	/*	if(user.getUserName().equals("tom") && user.getUserPassword().equals("tom123"))
			return true;
		return false;
	
	*/
		return userDao.validateLogin(user);	
	}
	@Override
	public String register(Register register) {
		
		return userDao.register(register);
	}

}
