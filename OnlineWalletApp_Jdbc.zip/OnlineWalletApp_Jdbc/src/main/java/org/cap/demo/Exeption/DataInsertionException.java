package org.cap.demo.Exeption;

public class DataInsertionException extends Exception{
	
	public DataInsertionException(String msg) {
		super(msg);
	}
}
