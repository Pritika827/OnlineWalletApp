package org.cap.demo.model;

public enum TransactionType {
	DEBIT,CREDIT
}
