package org.cap.demo.Exeption;

public class InvalidAccountNumberException extends Exception{
	
	public InvalidAccountNumberException(String msg) {
	super(msg);
	}

}
