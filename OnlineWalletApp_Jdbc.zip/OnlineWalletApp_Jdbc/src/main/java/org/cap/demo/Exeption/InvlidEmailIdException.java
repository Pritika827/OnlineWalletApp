package org.cap.demo.Exeption;

public class InvlidEmailIdException extends Exception{
	
	public InvlidEmailIdException(String msg) {
		super(msg);
	}

}
