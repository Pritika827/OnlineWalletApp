package org.cap.demo.Exeption;

public class EmptyAddressFieldException extends Exception{
	
	public EmptyAddressFieldException(String msg) {
		super(msg);
	}

}
