package org.cap.demo.model;

public enum AccountType {
	SAVING,CURRENT,LOAN,SALARY

}
