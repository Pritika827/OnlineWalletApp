package org.cap.demo.util;

public class InvalidEmailException extends Exception{
	public InvalidEmailException(String msg) {
		super(msg);
	}

}
