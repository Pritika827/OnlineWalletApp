package org.cap.demo.util;

public class InvalidBalanceException extends Exception{
	
	public InvalidBalanceException(String msg) {
		super(msg);
	}
}
