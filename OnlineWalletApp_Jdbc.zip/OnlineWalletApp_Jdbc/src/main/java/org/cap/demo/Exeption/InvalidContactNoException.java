package org.cap.demo.Exeption;

public class InvalidContactNoException extends Exception{
	
	public InvalidContactNoException(String msg) {
		super(msg);
	}

}
