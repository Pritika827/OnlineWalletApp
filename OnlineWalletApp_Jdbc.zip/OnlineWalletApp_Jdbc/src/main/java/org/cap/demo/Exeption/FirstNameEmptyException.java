package org.cap.demo.Exeption;

public class FirstNameEmptyException extends RuntimeException{

	public FirstNameEmptyException(String msg) {
		super(msg);
	}
}
