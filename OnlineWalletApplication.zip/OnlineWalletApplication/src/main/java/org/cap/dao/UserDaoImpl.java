package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.cap.model.TransactionType;


public class UserDaoImpl implements IUserDao{

	@Override
	public Customer validateLogin(Customer customer) {

		EntityManager entityManager=getEntityManager();

		EntityTransaction entityTransaction= entityManager.getTransaction();
		entityTransaction.begin();

		Query query= entityManager.createQuery("from Customer c where c.emailId=:uname and "
				+ " c.password=:upwd");
		query.setParameter("uname", customer.getEmailId());
		query.setParameter("upwd", customer.getPassword());

		List<Customer> users =query.getResultList();
		if(!users.isEmpty())
			return users.get(0);
		entityTransaction.commit();
		entityManager.close();
		return null;
	}


	private EntityManager getEntityManager() {
		EntityManagerFactory entityManagerFactory=
				Persistence.createEntityManagerFactory("capg");

		return entityManagerFactory.createEntityManager();
	}


	@Override
	public Customer registerCustomer(Customer customer, Address address) {
		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();

		entityManager.persist(customer); //generate customer ID pk
		address.setCustomer(customer);
		entityManager.persist(address);

		entityTransaction.commit();
		entityManager.close();
		return customer;
	}


	@Override
	public List<String> getAllCities() {
		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();
		String sql="select c.cityname from City c";

		List<String> cities= entityManager.createQuery(sql).getResultList();
		if(!cities.isEmpty())
			return cities;
		entityTransaction.commit();
		entityManager.close();

		return null;
	}


	@Override
	public Customer findCustomer(int customerId) {
		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();

		Customer customer=entityManager.find(Customer.class, customerId);
		if(customer!=null)
			return customer;
		entityTransaction.commit();
		entityManager.close();
		return null;
	}


	@Override
	public Account createAccount(Account account) {
		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();

		Customer customer=entityManager.find(Customer.class, account.getCustomer().getCustomerId());
		account.setCustomer(customer);

		entityManager.persist(account);			
		entityTransaction.commit();

		entityManager.close();
		return account;
	}


	@Override
	public List<Account> findAccountsByCustomer(Customer customer, String str) {

		EntityManager entityManager = getEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		Query query;
		if (str.equalsIgnoreCase("from")) {
			query = entityManager.createQuery("from Account a where a.customer=:customer");
		} else {
			query = entityManager.createQuery("from Account a where a.customer!=:customer");
		}
		query.setParameter("customer", customer);
		List<Account> accounts = query.getResultList();
		if (!accounts.isEmpty())
			return accounts;
		entityTransaction.commit();
		entityManager.close();
		return null;
	}

	@Override
	public Account findAccount(int accountno) {
		EntityManager entityManager = getEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();

		Account account = entityManager.find(Account.class, accountno);

		entityTransaction.commit();
		entityManager.close();
		return account;
	}
	

	@Override
	public Account transaction(int accountno, double amount, String transactiontype) {
		EntityManager entityManager = getEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();

	//	System.out.println("done"+amount);
	//	System.out.println("done"+transactiontype);

//		Transaction transaction=new Transaction(accountno, null, null, transactiontype, null, null, amount);
		Account account = entityManager.find(Account.class, accountno);
		
		if (transactiontype.equalsIgnoreCase("deposit")) {
			account.setBalance(account.getBalance() + amount);
		} else {
			account.setBalance(account.getBalance() - amount);
		}
		
		
//		entityManager.persist(transaction);
		
		entityTransaction.commit();
		entityManager.close();
		return account;
	}

	@Override
	public List<Account> getAllAccountByCustomer(int customerId) {
		EntityManager entityManager = getEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		
		String sql="from Account a where a.customer=:custId";
		
		Query query = entityManager.createQuery(sql);
		query.setParameter("custId", customerId);	
		List<Account> accounts= query.getResultList();
		
		entityTransaction.commit();
		entityManager.close();
		return accounts;
	}

	}