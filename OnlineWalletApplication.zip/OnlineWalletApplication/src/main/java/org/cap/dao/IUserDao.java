package org.cap.dao;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;


public interface IUserDao {
	public Customer validateLogin(Customer customer);
	
	public Customer registerCustomer(Customer customer,Address address);
	
	public List<String> getAllCities();
	
	public Customer findCustomer(int customerId);
	
	public Account createAccount(Account account);
	
	public List<Account> getAllAccountByCustomer(int customerId);

	//Account depositeAmount(Account accountNo, double amount, String accountType);

	//Account withdrawAmount(Account accountNo, double amount, String accountType);
	
	
	public List<Account> findAccountsByCustomer(Customer customer, String str);

	public Account findAccount(int accountno);
	
	public Account transaction(int accountno, double amount, String transactiontype);
	
	
}





