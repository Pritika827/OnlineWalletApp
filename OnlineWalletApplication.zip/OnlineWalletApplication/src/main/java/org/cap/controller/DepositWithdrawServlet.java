package org.cap.controller;

import java.io.Console;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.AccountType;
import org.cap.model.Customer;
import org.cap.service.IUserService;
import org.cap.service.UserServiceImpl;

/**
 * Servlet implementation class DepositWithdrawServlet
 */
@WebServlet("/DepositWithdrawServlet")
public class DepositWithdrawServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	IUserService userService;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		userService = new UserServiceImpl();
		PrintWriter printWriter = response.getWriter();
		

		HttpSession httpSession = request.getSession();
		int customerId = (int) httpSession.getAttribute("customerId");
		String customerName=httpSession.getAttribute("customerName").toString();

		int accountno = Integer.parseInt(request.getParameter("account"));
		double amount = Double.parseDouble(request.getParameter("amount"));
		String transactiontype = request.getParameter("transactiontype");

		Customer customer = userService.findCustomer(customerId);
		Account account = userService.findAccount(accountno);
		List<Account> accounts = userService.finAccountsByCustomer(customer,"from");

		if(transactiontype.equalsIgnoreCase("withdraw") && 
				amount>account.getBalance() && account.getAccountType()!=AccountType.LOAN) {
			//	response.sendRedirect("MainPageServlet");	
			printWriter.println("<!DOCTYPE html>\r\n"
					+ "<html>\r\n"
					+ "<head>\r\n"
					+ "<meta charset=\"ISO-8859-1\">\r\n"
					+ "<title>Deposit/withdraw</title>\r\n"
					+ "</head>\r\n"
					+ "<link\r\n"
					+ "	href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css\"\r\n"
					+ "	rel=\"stylesheet\"\r\n"
					+ "	integrity=\"sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3\"\r\n"
					+ "	crossorigin=\"anonymous\">\r\n"
					+ "</head>\r\n"
					+ "<link rel=\"stylesheet\"\r\n"
					+ "	href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\"\r\n"
					+ "	integrity=\"sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm\"\r\n"
					+ "	crossorigin=\"anonymous\">\r\n"
					+ "<script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\"\r\n"
					+ "	integrity=\"sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN\"\r\n"
					+ "	crossorigin=\"anonymous\"></script>\r\n"
					+ "<script\r\n"
					+ "	src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\"\r\n"
					+ "	integrity=\"sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q\"\r\n"
					+ "	crossorigin=\"anonymous\"></script>\r\n"
					+ "<script\r\n"
					+ "	src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"\r\n"
					+ "	integrity=\"sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl\"\r\n"
					+ "	crossorigin=\"anonymous\"></script>\r\n"
				
					+ "<body>\r\n"
					+ "	<section class=\"vh-100\" style=\"background-color: #0FAE2F;\">\r\n"
					+ "		<div class=\"container\">\r\n"
					+ "			<h3 class=\"fw-normal display-6 mb-2 pb-6 mt-2\"\r\n"
					+ "				style=\"letter-spacing: 1px; text-align: center; font-family: Algerian;\">Online\r\n"
					+ "				Wallet Application</h3>\r\n"
					+ "\r\n"
					+ "		</div>\r\n"
					+ "\r\n"
					+ "		<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">\r\n"
					+ "			<div class=\"container-fluid\">\r\n"
					+ "\r\n"
					+ "				<button class=\"navbar-toggler\" type=\"button\"\r\n"
					+ "					data-bs-toggle=\"collapse\" data-bs-target=\"#navbarSupportedContent\"\r\n"
					+ "					aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\"\r\n"
					+ "					aria-label=\"Toggle navigation\">\r\n"
					+ "					<span class=\"navbar-toggler-icon\"></span>\r\n"
					+ "				</button>\r\n"
					+ "				<div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">\r\n"
					+ "					<ul class=\"navbar-nav me-auto mb-2 mb-lg-0\">\r\n"
					+ "						<li class=\"nav-item\"><a class=\"nav-link active\"\r\n"
					+ "							aria-current=\"page\" href=\'MainPageServlet'>Home</a></li>\r\n"
					+ "						<li class=\"nav-item\">"
					+ "<a class=\"nav-link\" href='pages/CreateAccount.html'>create\r\n account</a></li>\r\n"
					+ "<li class=\"nav-item\"><a class=\"nav-link\" href=\"pages/AccountDetail.html\">account detail</a></li>\r\n"
					+ "						<li class=\"nav-item dropdown\"><a\r\n"
					+ "							class=\"nav-link dropdown-toggle\" href=\"#\"\r\n"
					+ "							id=\"navbarDropdownMenuLink\" data-toggle=\"dropdown\"\r\n"
					+ "							aria-haspopup=\"true\" aria-expanded=\"false\"> Transaction </a>\r\n"
					+ "							<div class=\"dropdown-menu\"\r\n"
					+ "								aria-labelledby=\"navbarDropdownMenuLink\">\r\n"
					+ "								<a class=\"dropdown-item\" href=\'DepositServlet'>deposite/withdraw</a> <a\r\n"
					+ "									class=\"dropdown-item\" href=\"#\">fund transfer</a> <a\r\n"
					+ "									class=\"dropdown-item\" href=\"#\">transaction history</a>\r\n"
					+ "							</div></li>\r\n"
					+ "\r\n"
					+ "					</ul>\r\n"
					+ "						<a class=\"btn btn-outline-success ml-2\" href='LogoutServlet'>logout</a>\r\n"
					+ "				</div>\r\n"
					+ "			</div>\r\n"
					+ "		</nav>\r\n"
					+ "\r\n"
					+ "		<p class=\"mx-4\" align=\"right\">Welcome "+customerName+"</p>\r\n"
					+"<center>"
					+ "<h1 align=\"center\">Deposit/withdraw</h1>\r\n"
					+ "<hr>\r\n"
					+ "<form method=\"post\" name=\"depositwithdraw\" action=\"DepositWithdrawServlet\" onsubmit=\"return myfunc()\">\r\n"
					+ "<div align=\"center\">\r\n"
					+ "	<table cellpadding=\"5px\">\r\n"
					+ "	<tr>\r\n"
					+ "			<td>Select Account:</td>\r\n"
					+ "			<td> \r\n"
					+ "				<select name=\"account\">"
					+ "			<option value=\"Select\">Select</option>");

			for(Account account1:accounts) {
				printWriter.println("<option value="+account1.getAccountNumber()+">"+account1.getAccountNumber()+ " "+account1.getAccountType()+"</option>");
			}
			printWriter.println("</select>\r\n"
					+ "			\r\n"
					+ "			</td>\r\n"
					+ "			<td>\r\n"
					+ "				<div id=\"errAccount\" class=\"errMsg\"></div>\r\n"
					+ "			</td>\r\n"
					+ "		</tr>"
					+ "<tr>\r\n"
					+ "	<td>Amount</td>\r\n"
					+ "	<td><input type=\"number\" name=\"amount\" size=20></td>\r\n"
					+ "	<td>\r\n"
					+ "		<div id=\"errAmount\" class=\"errMsg\">"
					+ "insufficient Balance"
					+ "<c:out value=\"${SessionScope.message}\" />\r\n"
					+ " <c:remove var=\"message\" scope=\"Session\" />"
					+ "</div>\r\n"
					+ "	</td>\r\n"
					+ "</tr>\r\n"
					+ "<tr>\r\n"
					+ "	<td>Choose Transaction type:</td>\r\n"
					+ "	<td>\r\n"
					+ "		<input type =\"radio\" name=\"transactiontype\" value=\"deposit\" checked=\"checked\">deposit\r\n"
					+ "		<input type =\"radio\" name=\"transactiontype\" value=\"withdraw\">withdraw\r\n"
					+ "	</td>\r\n"
					+ "</tr>"
					+ "<c:out value=\"${SessionScope.LoanError}\" />\r\n"
					+ "<c:remove var=\"LoanError\" scope=\"Session\" />"
					+ "<tr>\r\n"
					+ "			<td><button type=\"submit\" name=\"confirm\">Confirm</button>\r\n"
					+ "			</td>\r\n"
					+ "		</tr>");
		}
		else if(account.getAccountType()==AccountType.LOAN && transactiontype.equalsIgnoreCase("withdraw")) {

			//			Session.setAttribute("message", "You cannot withdraw from loan account");
			//			response.sendRedirect("DepositWithdrawFormServlet");
			//	response.sendRedirect("MainPageServlet");	

			printWriter.println("<!DOCTYPE html>\r\n"
					+ "<html>\r\n"
					+ "<head>\r\n"
					+ "<meta charset=\"ISO-8859-1\">\r\n"
					+ "<title>deposit withdraw</title>\r\n"
					+ "<link\r\n"
					+ "	href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css\"\r\n"
					+ "	rel=\"stylesheet\"\r\n"
					+ "	integrity=\"sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3\"\r\n"
					+ "	crossorigin=\"anonymous\">\r\n"
					+ "</head>\r\n"
					+ "<link rel=\"stylesheet\"\r\n"
					+ "	href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\"\r\n"
					+ "	integrity=\"sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm\"\r\n"
					+ "	crossorigin=\"anonymous\">\r\n"
					+ "<script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\"\r\n"
					+ "	integrity=\"sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN\"\r\n"
					+ "	crossorigin=\"anonymous\"></script>\r\n"
					+ "<script\r\n"
					+ "	src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\"\r\n"
					+ "	integrity=\"sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q\"\r\n"
					+ "	crossorigin=\"anonymous\"></script>\r\n"
					+ "<script\r\n"
					+ "	src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"\r\n"
					+ "	integrity=\"sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl\"\r\n"
					+ "	crossorigin=\"anonymous\"></script>\r\n"
					
					+ "</head>\r\n"
					+ "<body>\r\n"
					+ "	<section class=\"vh-100\" style=\"background-color: #0FAE2F;\">\r\n"
					+ "		<div class=\"container\">\r\n"
					+ "			<h3 class=\"fw-normal display-6 mb-2 pb-6 mt-2\"\r\n"
					+ "				style=\"letter-spacing: 1px; text-align: center; font-family: Algerian;\">Online\r\n"
					+ "				Wallet Application</h3>\r\n"
					+ "\r\n"
					+ "		</div>\r\n"
					+ "\r\n"
					+ "		<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">\r\n"
					+ "			<div class=\"container-fluid\">\r\n"
					+ "\r\n"
					+ "				<button class=\"navbar-toggler\" type=\"button\"\r\n"
					+ "					data-bs-toggle=\"collapse\" data-bs-target=\"#navbarSupportedContent\"\r\n"
					+ "					aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\"\r\n"
					+ "					aria-label=\"Toggle navigation\">\r\n"
					+ "					<span class=\"navbar-toggler-icon\"></span>\r\n"
					+ "				</button>\r\n"
					+ "				<div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">\r\n"
					+ "					<ul class=\"navbar-nav me-auto mb-2 mb-lg-0\">\r\n"
					+ "						<li class=\"nav-item\"><a class=\"nav-link active\"\r\n"
					+ "							aria-current=\"page\" href=\'MainPageServlet'>Home</a></li>\r\n"
					+ "						<li class=\"nav-item\">"
					+ "<a class=\"nav-link\" href='pages/CreateAccount.html'>create\r\n account</a></li>\r\n"
					+ "<li class=\"nav-item\"><a class=\"nav-link\" href=\"pages/AccountDetail.html\">account detail</a></li>\r\n"
					+ "						<li class=\"nav-item dropdown\"><a\r\n"
					+ "							class=\"nav-link dropdown-toggle\" href=\"#\"\r\n"
					+ "							id=\"navbarDropdownMenuLink\" data-toggle=\"dropdown\"\r\n"
					+ "							aria-haspopup=\"true\" aria-expanded=\"false\"> Transaction </a>\r\n"
					+ "							<div class=\"dropdown-menu\"\r\n"
					+ "								aria-labelledby=\"navbarDropdownMenuLink\">\r\n"
					+ "								<a class=\"dropdown-item\" href=\'DepositServlet'>deposite/withdraw</a> <a\r\n"
					+ "									class=\"dropdown-item\" href=\"#\">fund transfer</a> <a\r\n"
					+ "									class=\"dropdown-item\" href=\"#\">transaction history</a>\r\n"
					+ "							</div></li>\r\n"
					+ "\r\n"
					+ "					</ul>\r\n"
					+ "						<a class=\"btn btn-outline-success ml-2\" href='LogoutServlet'>logout</a>\r\n"
					+ "				</div>\r\n"
					+ "			</div>\r\n"
					+ "		</nav>\r\n"
					+ "\r\n"
					+ "		<p class=\"mx-4\" align=\"right\">Welcome "+customerName+"</p>\r\n"
					+"<center>"
				
					+ "\r\n"
			//		+ "<h1 align=\"center\">Deposit/withdraw</h1>\r\n"
			//		+ "<hr>\r\n"
					+ "<form method=\"post\" name=\"depositwithdraw\" action=\"DepositWithdrawServlet\" >\r\n"
					+ "<div align=\"center\">\r\n"
					+ "	<table cellpadding=\"5px\">\r\n"
					+ "	<tr>\r\n"
					+ "			<td>Select Account:</td>\r\n"
					+ "			<td> \r\n"
					+ "				<select name=\"account\">"
					+ "			<option value=\"Select\">Select</option>");

			for(Account account1:accounts) {
				printWriter.println("<option value="+account1.getAccountNumber()+">"+account1.getAccountNumber()+ " "+account1.getAccountType()+"</option>");
			}

			printWriter.println("</select>\r\n"
					+ "			\r\n"
					+ "			</td>\r\n"
					+ "			<td>\r\n"
					+ "				<div id=\"errAccount\" class=\"errMsg\" style=\"color:red\">You cannot withdraw from loan account</div>\r\n"
					+ "			</td>\r\n"
					+ "		</tr>"
					+ "<tr>\r\n"
					+ "	<td>Amount</td>\r\n"
					+ "	<td><input type=\"number\" name=\"amount\" size=20></td>\r\n"
					+ "	<td>\r\n"
					+ "		<div id=\"errAmount\" class=\"errMsg\">"
					+ "<c:out value=\"${SessionScope.message}\" />\r\n"
					+ " <c:remove var=\"message\" scope=\"Session\" />"
					+ "</div>\r\n"
					+ "	</td>\r\n"
					+ "</tr>\r\n"
					+ "<tr>\r\n"
					+ "	<td>Choose Transaction type:</td>\r\n"
					+ "	<td>\r\n"
					+ "		<input type =\"radio\" name=\"transactiontype\" value=\"deposit\" checked=\"checked\">deposit\r\n"
					+ "		<input type =\"radio\" name=\"transactiontype\" value=\"withdraw\">withdraw\r\n"
					+ "	</td>\r\n"
					+ "</tr>"
					+ "<c:out value=\"${SessionScope.LoanError}\" />\r\n"
					+ "<c:remove var=\"LoanError\" scope=\"Session\" />"
					+ "<tr>\r\n"
					+ "			<td><button type=\"submit\" name=\"confirm\">Confirm</button>\r\n"
					+ "			</td>\r\n"
					+ "		</tr>");
		}
		else if(account.getAccountType()==AccountType.LOAN && transactiontype.equalsIgnoreCase("deposit")){
			Account account1 = userService.transaction(accountno, amount, "withdraw");
		//	printWriter.println("<div style='color:red;'>Amount deposite Successfully !! </div>");
			//response.sendRedirect("MainPageServlet");	
			printWriter.println(""
					+ "<html>"
					+ "<body>"
					+ "<script>"
					+ "alert('Amount deposite Successfully !!')"
					+ "</script>"
					+ "</body>"
					+ "</html>");
			request.getRequestDispatcher("MainPageServlet").include(request, response);

		}else {
			Account account1 = userService.transaction(accountno, amount, transactiontype);

		//	response.sendRedirect("MainPageServlet");	
			request.getRequestDispatcher("MainPageServlet").include(request, response);
		}

	}

}
