package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.service.IUserService;
import org.cap.service.UserServiceImpl;


@WebServlet("/FundTransferServlet1")
public class FundTransferServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
     private IUserService userService; 
    public FundTransferServlet1() {
        super();
     } 
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		userService=new UserServiceImpl();
		HttpSession httpSession=request.getSession(true);
		int customerId = (int) httpSession.getAttribute("customerId");
		String customerName=httpSession.getAttribute("customerName").toString();
		
		Customer customer = userService.findCustomer(customerId);
		List<Account> accounts = userService.finAccountsByCustomer(customer,"from");
		PrintWriter printWriter = response.getWriter();
			
	printWriter.print(""
			+ "<!DOCTYPE html>\r\n"
			+ "<html>\r\n"
			+ "<head>\r\n"
			+ "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n"
			+ "	<link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css\"\r\n"
			+ "	rel=\"stylesheet\"\r\n"
			+ "	integrity=\"sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3\"\r\n"
			+ "	crossorigin=\"anonymous\">\r\n"
			+ "</head>\r\n"
			+ "<link rel=\"stylesheet\"\r\n"
			+ "	href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\"\r\n"
			+ "	integrity=\"sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm\"\r\n"
			+ "	crossorigin=\"anonymous\">\r\n"
			+ "<script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\"\r\n"
			+ "	integrity=\"sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN\"\r\n"
			+ "	crossorigin=\"anonymous\"></script>\r\n"
			+ "<script\r\n"
			+ "	src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\"\r\n"
			+ "	integrity=\"sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q\"\r\n"
			+ "	crossorigin=\"anonymous\"></script>\r\n"
			+ "<script\r\n"
			+ "	src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"\r\n"
			+ "	integrity=\"sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl\"\r\n"
			+ "	crossorigin=\"anonymous\"></script>\r\n"
			
			+ "</head>\r\n"
			+ "<body>\r\n"
			+ "	<section class=\"vh-100\" style=\"background-color: #0FAE2F;\">\r\n"
			+ "		<div class=\"container\">\r\n"
			+ "			<h3 class=\"fw-normal display-6 mb-2 pb-6 mt-2\"\r\n"
			+ "				style=\"letter-spacing: 1px; text-align: center; font-family: Algerian;\">Online\r\n"
			+ "				Wallet Application</h3>\r\n"
			+ "\r\n"
			+ "		</div>\r\n"
			+ "\r\n"
			+ "		<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">\r\n"
			+ "			<div class=\"container-fluid\">\r\n"
			+ "\r\n"
			+ "				<button class=\"navbar-toggler\" type=\"button\"\r\n"
			+ "					data-bs-toggle=\"collapse\" data-bs-target=\"#navbarSupportedContent\"\r\n"
			+ "					aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\"\r\n"
			+ "					aria-label=\"Toggle navigation\">\r\n"
			+ "					<span class=\"navbar-toggler-icon\"></span>\r\n"
			+ "				</button>\r\n"
			+ "				<div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">\r\n"
			+ "					<ul class=\"navbar-nav me-auto mb-2 mb-lg-0\">\r\n"
			+ "						<li class=\"nav-item\"><a class=\"nav-link active\"\r\n"
			+ "							aria-current=\"page\" href=\'MainPageServlet'>Home</a></li>\r\n"
			+ "						<li class=\"nav-item\">"
			+ "							<a class=\"nav-link\" href='CreateAccount'>create\r\n account</a></li>\r\n"
			+ "						<li class=\"nav-item\">"
			+ "					<a class=\"nav-link\" href=\"AccountDetail\">account detail</a></li>\r\n"
			+ "						<li class=\"nav-item dropdown\"><a\r\n"
			+ "							class=\"nav-link dropdown-toggle\" href=\"#\"\r\n"
			+ "							id=\"navbarDropdownMenuLink\" data-toggle=\"dropdown\"\r\n"
			+ "							aria-haspopup=\"true\" aria-expanded=\"false\"> Transaction </a>\r\n"
			+ "							<div class=\"dropdown-menu\"\r\n"
			+ "								aria-labelledby=\"navbarDropdownMenuLink\">\r\n"
			+ "								<a class=\"dropdown-item\" href=\'DepositServlet'>deposite/withdraw</a> <a\r\n"
			+ "									class=\"dropdown-item\" href=\'FundTransferServlet1'>fund transfer</a> <a\r\n"
			+ "									class=\"dropdown-item\" href=\"#\">transaction history</a>\r\n"
			+ "							</div></li>\r\n"
			+ "\r\n"
			+ "					</ul>\r\n"
			+ "						<a class=\"btn btn-outline-success ml-2\" href='LogoutServlet'>logout</a>\r\n"
			+ "				</div>\r\n"
			+ "			</div>\r\n"
			+ "		</nav>\r\n"
			+ "\r\n"
			+ "		<p class=\"mx-4\" align=\"right\">Welcome "+customerName+"</p>\r\n"
	

			+ "<form method=\"post\" name=\"register\" action=\"FundTransferServlet\" onsubmit=\"return registerFormValidation()\">\r\n"
			+ "<div align=\"center\">\r\n"
			+ "	<table cellpadding=\"5px\">\r\n"
			+ "	\r\n"
			+ "		<tr>\r\n"
			+ "			<td>Please Enter your account number : </td>\r\n"
			+ "			<td> <input type=\"text\" name=\"fromaccount\" size=\"20\"></td>\r\n"
			+ "			<td>\r\n"
			+ "				<div id=\"errFromacc\" class=\"errMsg\"></div>\r\n"
			+ "			</td>\r\n"
			+ "		</tr>	\r\n"
			+ "		<tr>\r\n"
			+ "			<td>Please enter account number to transfer funds : </td>\r\n"
			+ "			<td> <input type=\"text\" name=\"toaccount\" size=\"20\"></td>\r\n"
			+ "			<td>\r\n"
			+ "				<div id=\"errToacc\" class=\"errMsg\"></div>\r\n"
			+ "			</td>\r\n"
			+ "		</tr>\r\n"
			+ "		\r\n"
			+ "		<tr>\r\n"
			+ "			<td>Please enter funds to transfer : </td>\r\n"
			+ "			<td> <input type=\"text\" name=\"account\" size=\"20\"></td>\r\n"
			+ "			<td>\r\n"
			+ "				<div id=\"errFunds\" class=\"errMsg\"></div>\r\n"
			+ "			</td>\r\n"
			+ "		</tr>	\r\n"
			+ "		<tr>\r\n"
			+ "		<td> </td>\r\n"
			+ "			<td><button type=\"submit\" name=\"register\">Transfer</button>\r\n"
			+ "			<button type=\"reset\" name=\"clear\">Cancel</button> \r\n"
			+ "			</td>\r\n"
			+ "		</tr>\r\n"
			+ "	</table>\r\n"
			+ "</div>\r\n"
			+ "</form>\r\n"
			+ "</body>\r\n"
			+ "</html>"
			+ "");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
