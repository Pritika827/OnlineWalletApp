package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.service.IUserService;
import org.cap.service.UserServiceImpl;


@WebServlet("/DepositWithdrawFormServlet")
public class DepositWithdrawFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	IUserService userService;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		userService = new UserServiceImpl();
		
		HttpSession httpSession = request.getSession(true);
		int customerId = (int) httpSession.getAttribute("customerId");
//		String message = request.getSession().getAttribute("message").toString();
//		request.getSession(true).removeAttribute("message");
		
		Customer customer = userService.findCustomer(customerId);
		
		List<Account> accounts = userService.finAccountsByCustomer(customer,"from");
		PrintWriter printWriter = response.getWriter();
		
		printWriter.println("<!DOCTYPE html>\r\n"
				+ "<html>\r\n"
				+ "<head>\r\n"
				+ "<meta charset=\"ISO-8859-1\">\r\n"
				+ "<title>Create Account</title>\r\n"
				+ "<script type=\"text/javascript\" src=\"script/TransactionValidation.js\"></script>\r\n"
				+ "<link type=\"text/css\" rel=\"stylesheet\" href=\"css/styles.css\">\r\n"
				+ "</head>\r\n"
				+ "<body>\r\n"
				+ "\r\n"
				+ "<h1 align=\"center\">deposit withdraw</h1>\r\n"
				+ "<hr>\r\n"
				+ "<form method=\"post\" name=\"depositwithdraw\" action=\"DepositServlet\" onsubmit=\"return myfunc()\">\r\n"
				+ "<div align=\"center\">\r\n"
				+ "	<table cellpadding=\"5px\">\r\n"
				+ "	<tr>\r\n"
				+ "			<td>Select Account:</td>\r\n"
				+ "			<td> \r\n"
				+ "				<select name=\"account\">"
				+ "			<option value=\"Select\">Select</option>");
		
		for(Account account:accounts) {
			printWriter.println("<option value="+account.getAccountNumber()+">"+account.getAccountNumber()+ " "+account.getAccountType()+"</option>");
		}
		
		printWriter.println("</select>\r\n"
				+ "			\r\n"
				+ "			</td>\r\n"
				+ "			<td>\r\n"
				+ "				<div id=\"errAccount\" class=\"errMsg\"></div>\r\n"
				+ "			</td>\r\n"
				+ "		</tr>"
				+ "<tr>\r\n"
				+ "	<td>Amount</td>\r\n"
				+ "	<td><input type=\"number\" name=\"amount\" size=20></td>\r\n"
				+ "	<td>\r\n"
				+ "		<div id=\"errAmount\" class=\"errMsg\">"
				+ "<c:out value=\"${SessionScope.message}\" />\r\n"
				+ " <c:remove var=\"message\" scope=\"Session\" />"
				+ "</div>\r\n"
				+ "	</td>\r\n"
				+ "</tr>\r\n"
				+ "<tr>\r\n"
				+ "	<td>Choose Transaction type:</td>\r\n"
				+ "	<td>\r\n"
				+ "		<input type =\"radio\" name=\"transactiontype\" value=\"deposit\" checked=\"checked\">deposit\r\n"
				+ "		<input type =\"radio\" name=\"transactiontype\" value=\"withdraw\">withdraw\r\n"
				+ "	</td>\r\n"
				+ "</tr>"
				+ "<c:out value=\"${SessionScope.LoanError}\" />\r\n"
				+ "<c:remove var=\"LoanError\" scope=\"Session\" />"
				+ "<tr>\r\n"
				+ "			<td><button type=\"submit\" name=\"confirm\">Confirm</button>\r\n"
				+ "			</td>\r\n"
				+ "		</tr>");
	}

}
