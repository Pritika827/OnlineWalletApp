package org.cap.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.model.Customer;
import org.cap.service.IUserService;
import org.cap.service.UserServiceImpl;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private IUserService userService;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
	
		userService=new UserServiceImpl();
		
		String emailid=request.getParameter("userName");
		String password=request.getParameter("userPwd");
		
		Customer user2=new Customer(emailid, password);	
		Customer customer=userService.validateLogin(user2);
		
		if(customer!=null) {			
			HttpSession session=request.getSession(true);
		//	session.setAttribute("cust", customer);
			session.setAttribute("customerId", customer.getCustomerId());
			session.setAttribute("customerName", customer.getFirstName() + " " + customer.getLastName());
			response.sendRedirect("MainPageServlet");
		}
		else
			response.sendRedirect("index.html");
	}

}
