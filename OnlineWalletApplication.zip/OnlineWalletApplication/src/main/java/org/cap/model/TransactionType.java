package org.cap.model;

public enum TransactionType {
	DEBIT,CREDIT
}
