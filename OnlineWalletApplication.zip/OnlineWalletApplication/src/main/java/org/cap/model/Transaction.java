package org.cap.model;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
@Entity
public class Transaction {
	@Id
	@GeneratedValue
	private int transcationId;
	private TransactionType transactionType;
	private LocalDateTime transactionDateTime=LocalDateTime.now();
	private String descreption;
	
	@ManyToOne
	@JoinColumn(name="fromAccount")
	private Account fromAccount;
	
	@ManyToOne
	@JoinColumn(name="toAccount")
	private Account toAccount;
	
	private double amount;
	
	public int getTranscationId() {
		return transcationId;
	}
	public void setTranscationId(int transcationId) {
		this.transcationId = transcationId;
	}
	public TransactionType getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(TransactionType transactionType) {
		this.transactionType = transactionType;
	}
	public LocalDateTime getTransactionDateTime() {
		return transactionDateTime;
	}
	public void setTransactionDateTime(LocalDateTime transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}
	public String getDescreption() {
		return descreption;
	}
	public void setDescreption(String descreption) {
		this.descreption = descreption;
	}
	public Account getFromAccount() {
		return fromAccount;
	}
	public void setFromAccount(Account fromAccount) {
		this.fromAccount = fromAccount;
	}
	public Account getToAccount() {
		return toAccount;
	}
	public void setToAccount(Account toAccount) {
		this.toAccount = toAccount;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Transaction(TransactionType transactionType, LocalDateTime transactionDateTime,
			String descreption, double amount) {
		super();
//		this.transcationId = transcationId;
		this.transactionType = transactionType;
		this.transactionDateTime = transactionDateTime;
		this.descreption = descreption;
//		this.fromAccount = fromAccount;
//		this.toAccount = toAccount;
		this.amount = amount;
	}
	public Transaction() {
		super();
	}
	public Transaction(TransactionType valueOf, double parseDouble, LocalDateTime now, String description,
			Account account) {
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	public Transaction(int transcationId, TransactionType transactionType, LocalDateTime transactionDateTime,
			String descreption, Account fromAccount, Account toAccount, double amount) {
		super();
		this.transcationId = transcationId;
		this.transactionType = transactionType;
		this.transactionDateTime = transactionDateTime;
		this.descreption = descreption;
		this.fromAccount = fromAccount;
		this.toAccount = toAccount;
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Transaction [transcationId=" + transcationId + ", transactionType=" + transactionType
				+ ", transactionDateTime=" + transactionDateTime + ", descreption=" + descreption + ", fromAccount="
				+ fromAccount + ", toAccount=" + toAccount + ", amount=" + amount + "]";
	}
	

	
	
}
