package org.cap.service;

import java.util.List;

import org.cap.dao.IUserDao;
import org.cap.dao.UserDaoImpl;
import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;

public class UserServiceImpl implements IUserService{

	private IUserDao userDao = new UserDaoImpl();


	public UserServiceImpl() {
		this.userDao=new UserDaoImpl();
	}

	public UserServiceImpl(IUserDao userDao) {
		this.userDao=userDao;
	}

	@Override
	public Customer validateLogin(Customer customer) {
		//if(user.getUserName().equals("tom") &&
		//	user.getUserPassword().equals("tom123"))
		return userDao.validateLogin(customer);
	}
	@Override
	public Customer registerCustomer(Customer customer, Address address) {
		return userDao.registerCustomer(customer, address);
	}
	@Override
	public List<String> getAllCities() {
		return userDao.getAllCities();
	}
	@Override
	public Customer findCustomer(int customerId) {
		return userDao.findCustomer(customerId);
	}
	@Override
	public Account createAccount(Account account) {
		return userDao.createAccount(account);
	}
	@Override
	public List<Account> finAccountsByCustomer(Customer customer, String str) {
		return userDao.findAccountsByCustomer(customer, str);
	}
	@Override
	public Account transaction(int accountno, double amount, String transactiontype) {
		return userDao.transaction(accountno, amount, transactiontype);
	}
	@Override
	public Account findAccount(int accountno) {
		return userDao.findAccount(accountno);
	}

	@Override
	public List<Account> getAllAccountByCustomer(int customerId) {
		return userDao.getAllAccountByCustomer(customerId);
	}
}
