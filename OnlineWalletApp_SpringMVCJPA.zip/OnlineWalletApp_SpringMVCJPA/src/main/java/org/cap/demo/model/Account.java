package org.cap.demo.model;

/*-------------------------POJO-------------------*/
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

@SequenceGenerator(initialValue = 10000,sequenceName = "accSeq",name = "accSeq")
@Entity
public class Account {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "accSeq")
	private int accountNumber; 
	
	private AccountType accountType; 
	
	private LocalDate openingDate=LocalDate.now();
	private double balance; 
	private String description;
	
	
	@ManyToOne
	@JoinColumn(name = "registration_fk")
	private Registration registration;
	
	
/*-------------------------------Constructor--------------------------------------------*/
	public Account(int accountNumber, AccountType accountType, LocalDate openingDate, double balance,
			String description) {
		super();
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.openingDate = openingDate;
		this.balance = balance;
		this.description = description;
	}

	public Account( AccountType accountType, LocalDate openingDate, double balance,
			String description, Registration registration) {
		super();
	
		this.accountType = accountType;
		this.openingDate = openingDate;
		this.balance = balance;
		this.description = description;
		this.registration = registration;
	}
	/*-------------------------------getter & setter--------------------------------------------*/

	public Registration getCustomer() {
		return registration;
	}

	public void setCustomer(Registration registration) {
		this.registration = registration;
	}

	public Account() {
		super();
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public AccountType getAccountType() {
		return accountType;
	}

	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}

	public LocalDate getOpeningDate() {
		return openingDate;
	}

	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	
	/*---------------------------------toString() method------------------------------------------*/

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", accountType=" + accountType + ", openingDate="
				+ openingDate + ", balance=" + balance + ", description=" + description  + "]";
	}

	
		
}
