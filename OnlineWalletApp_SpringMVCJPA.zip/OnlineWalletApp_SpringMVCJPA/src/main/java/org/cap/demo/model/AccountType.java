package org.cap.demo.model;

/*-------------------------------Constant data-------------------------------------------*/

public enum AccountType {
	SAVINGS,
	CURRENT,
	LOAN,
	SALARY
}
