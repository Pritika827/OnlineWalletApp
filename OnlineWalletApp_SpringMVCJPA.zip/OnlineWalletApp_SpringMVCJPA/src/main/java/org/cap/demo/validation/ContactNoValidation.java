package org.cap.demo.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ContactNoValidation implements ConstraintValidator<ContactNo, String>{

	@Override
	public void initialize(ContactNo constraintAnnotation) {

	}

	@Override
	public boolean isValid(String contactNo, ConstraintValidatorContext context) {
		if(contactNo==null)
			return false;
		if(contactNo.matches("\\d{10}")) 
			return true;
		return false;
	}

}
