package org.cap.demo.service;

import java.util.List;
import java.util.Optional;

import org.cap.demo.dao.IUserDao;
import org.cap.demo.model.Account;
import org.cap.demo.model.Address;
import org.cap.demo.model.Registration;
import org.cap.demo.model.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("userService")
public class UserServiceImpl implements IUserService{

	@Autowired
	private IUserDao userDao;

	@Override
	public Optional<Registration> saveRegistration(Registration registration,Address address) {
		return userDao.saveRegistration(registration, address);
	}

	@Override
	public Optional<Registration> validateUserLogin(Registration registration) {
		return userDao.validateUserLogin(registration);
	}

	@Override
	public Optional<Account> createAccount(Account account) {
		return userDao.createAccount(account);
	}

	@Override
	public Optional<Account> depositAmount(Account account, double balance) {
		return userDao.depositAmount(account, balance);
	}

	@Override
	public Optional<Account> withdrawAmount(Account account, double amount) {
		return userDao.withdrawAmount(account, amount);
	}

	@Override
	public Optional<Account> transferAmount(Account account, double amount, int rec_ac_no) {
		return userDao.transferAmount(account, amount, rec_ac_no);
	}

	@Override
	public Optional<List<Transaction>> transactionDetails(Account account) {
		return userDao.transactionDetails(account);
	}

	@Override
	public Optional<List<Transaction>> transactionParticularDate(Account account, String start_date, String end_date) {
		return userDao.transactionParticularDate(account, start_date, end_date);
	}

}
