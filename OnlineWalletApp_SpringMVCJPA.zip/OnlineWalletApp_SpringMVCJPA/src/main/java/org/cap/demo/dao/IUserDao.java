package org.cap.demo.dao;

import java.util.List;
import java.util.Optional;

import org.cap.demo.model.Account;
import org.cap.demo.model.Address;
import org.cap.demo.model.Registration;
import org.cap.demo.model.Transaction;


public interface IUserDao {

	public Optional<Registration> validateUserLogin(Registration registration);
	
	public Optional<Registration> saveRegistration(Registration registration,Address address);
	
	public Optional<Account> createAccount(Account account); 

	public Optional<Account> depositAmount(Account account, double amount);

	public Optional<Account> withdrawAmount(Account account, double amount);

	public Optional<Account> transferAmount(Account account, double amount, int rec_ac_no);

	public Optional<List<Transaction>> transactionDetails(Account account);

	public Optional<List<Transaction>> transactionParticularDate(Account account, String start_date, String end_date);


}
