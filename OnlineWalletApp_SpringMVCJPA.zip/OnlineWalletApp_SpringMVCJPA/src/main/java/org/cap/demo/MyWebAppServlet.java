package org.cap.demo;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

public class MyWebAppServlet extends 
AbstractAnnotationConfigDispatcherServletInitializer
/* base class to initialize Spring application in Servlet container environment. 
 * It's an extension of WebApplicationInitializer.*/

{
	@Override
	protected Class<?>[] getRootConfigClasses() {
		return new Class[] {MyWebInitializerConfig.class};
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		return null;
	}

	@Override
	protected String[] getServletMappings() {		
		return new String[]{"/"};
	}

}
