package org.cap.demo.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.cap.demo.model.Registration;
import org.cap.demo.model.Transaction;
import org.cap.demo.model.TransactionType;
import org.cap.demo.model.Account;
import org.cap.demo.model.Address;

import org.springframework.stereotype.Repository;

@Transactional
@Repository("userDao")
public class UserDaoImpl implements IUserDao {

	@PersistenceContext
	private EntityManager entityManager; 
	
/*-------------------------------------LOGIN-------------------------------*/
	@Override
	public Optional<Registration> validateUserLogin(Registration registration) {
		//	Optional<UserDetails> optional=Optional.empty();

		String sql="from Registration user where user.emailId=:uemail and user.password=:upwd ";
		javax.persistence.Query query = entityManager.createQuery(sql);
		query.setParameter("uemail", registration.getEmailId());
		query.setParameter("upwd", registration.getPassword());

		List<Registration> registrations = query.getResultList();
		//System.out.println(registrations);
		if(registrations.size()>0)
			return Optional.of(registrations.get(0));
		return Optional.empty();
	}

	
/*-----------------------------save registration detail of customer-------------------------------*/
	@Override
	public Optional<Registration> saveRegistration(Registration registration,Address address) {
		entityManager.persist(registration);
		address.setRegistration(registration);
		entityManager.persist(address);
		
		
	
		return Optional.ofNullable(registration);
	}

/*------------------------------create account by register customer-------------------------------*/
	@Override
	public Optional<Account> createAccount(Account account) {
		entityManager.persist(account);
		return Optional.ofNullable(account);
	}

/*------------------------choose account type and deposite amount in wallet---------------------------*/
	@Override
	public Optional<Account> depositAmount(Account account, double amount) {
		System.out.println(account.getAccountType().ordinal());
		System.out.println(account.getCustomer().getRegistrationId());

		String sql = "from Account where registration_fk =: custId and accountType=: atype";
		Query query = entityManager.createQuery(sql);
		query.setParameter("custId", account.getCustomer().getRegistrationId());
		query.setParameter("atype", account.getAccountType());
		System.out.println("List result set");
		List<Account> acc = query.getResultList();
		System.out.println(acc);
		System.out.println("Account number in DAO layer "+ acc.get(0).getAccountNumber());
		int acno=acc.get(0).getAccountNumber();

		if (acc.size()>0) {
			String sql1 = "update Account set balance=balance+" +amount+ " where accountNumber="+acno;
			Query query1 = entityManager.createQuery(sql1);
			query1.executeUpdate();

			account.setAccountNumber(acno);
			Transaction transaction = new Transaction(LocalDate.now(),amount,TransactionType.CREDIT,account);
			entityManager.persist(transaction);
			return Optional.of(acc.get(0));
		}
		return Optional.empty();
	}

/*------------------------choose account type and withdraw amount in wallet---------------------------*/
	@Override
	public Optional<Account> withdrawAmount(Account account, double amount) {
		System.out.println(account.getAccountType().ordinal());
		System.out.println(account.getCustomer().getRegistrationId());

		String sql = "from Account where registration_fk =: custId and accountType=: atype";
		Query query = entityManager.createQuery(sql);
		query.setParameter("custId", account.getCustomer().getRegistrationId());
		query.setParameter("atype", account.getAccountType());
		System.out.println("List result set");
		
		List<Account> acc = query.getResultList();
		System.out.println(acc);
		System.out.println("Account number in DAO layer "+ acc.get(0).getAccountNumber());
		int acno=acc.get(0).getAccountNumber();
		double balance = acc.get(0).getBalance();

		if (acc.size()>0) {
			if(balance>=amount) {
				String sql1 = "update Account set balance=balance-" +amount+ " where accountNumber="+acno;
				Query query1 = entityManager.createQuery(sql1);
				query1.executeUpdate();

				account.setAccountNumber(acno);
				Transaction transaction = new Transaction(LocalDate.now(),amount,TransactionType.DEBIT,account);
				entityManager.persist(transaction);
				return Optional.of(acc.get(0));
			}
			return Optional.empty();
		}	
		return Optional.empty();
	}
	
/*--------------------choose account type and transfer amount one wallet to another amount---------------------*/
	@Override
	public Optional<Account> transferAmount(Account account, double amount, int receiverAc) {
		// TODO Auto-generated method stub
		System.out.println("Tranfer Method started ---------");
		System.out.println(account.getAccountType().ordinal());
		System.out.println(account.getCustomer().getRegistrationId());

		String sql = "from Account where registration_fk =: custId and accountType=: atype";
		Query query = entityManager.createQuery(sql);
		query.setParameter("custId", account.getCustomer().getRegistrationId());
		query.setParameter("atype", account.getAccountType());
		System.out.println("List result set");
		
		System.out.println(account.getAccountType());
		List<Account> acc = query.getResultList();
		System.out.println(acc);
		System.out.println("Account number in DAO layer "+ acc.get(0).getAccountNumber());
		int acno=acc.get(0).getAccountNumber();
		double balance=acc.get(0).getBalance();
		System.out.println(balance);
		
		if (acc.size()>0) {
			if (balance >=amount) {
				String sql1 = "update Account set balance=balance-" +amount+ " where accountNumber="+acno;
				String sql2 = "update Account set balance=balance+" +amount+ " where accountNumber="+receiverAc;
				Query query1 = entityManager.createQuery(sql1);
				query1.executeUpdate();

				Query query2 = entityManager.createQuery(sql2);
				query2.executeUpdate();

				account.setAccountNumber(acno);
				Transaction transaction = new Transaction(LocalDate.now(),amount,TransactionType.DEBIT,account);
				entityManager.persist(transaction);

				Account ac = new Account();
				ac.setAccountNumber(receiverAc);
				Transaction transaction1 = new Transaction(LocalDate.now(),amount,TransactionType.CREDIT,ac);
				entityManager.persist(transaction1);
				return Optional.of(acc.get(0));
			}
			return Optional.empty();
		}
		return Optional.empty();
	}
	
/*------------------------choose account type and show transaction detail---------------------------*/	
	@Override
	public Optional<List<Transaction>> transactionDetails(Account account) {
		String sql = "from Account where registration_fk =: custId and accountType=: atype";
		Query query = entityManager.createQuery(sql);
		query.setParameter("custId", account.getCustomer().getRegistrationId());
		query.setParameter("atype", account.getAccountType());
		List<Account> acc = query.getResultList();
		int acno=acc.get(0).getAccountNumber();
		
		sql = "from Transaction where account_fk="+acno;
		
		query = entityManager.createQuery(sql);
		List<Transaction> trans = query.getResultList();

		for(int i=0;i<trans.size();i++){
			System.out.println(trans.get(i));
		} 		
		if(trans.size()>0)
			return Optional.of(trans);			
		else
			return Optional.empty();
	}

/*----------------choose account type and show transaction according to date search-------------------*/
	@Override
	public Optional<List<Transaction>> transactionParticularDate(Account account, String start_date, String end_date) {
		
		String sql = "from Account where registration_fk =: custId and accountType=: atype";
		Query query = entityManager.createQuery(sql);
		query.setParameter("custId", account.getCustomer().getRegistrationId());
		query.setParameter("atype", account.getAccountType());
		List<Account> acc = query.getResultList();
		int acno=acc.get(0).getAccountNumber();
		sql = "from Transaction where account_fk="+acno+" and transactionDate >='"+start_date+"' and transactionDate <= '"+end_date+"'";
		query = entityManager.createQuery(sql);
		List<Transaction> trans = query.getResultList();
		System.out.println(trans);
		for(int i=0;i<trans.size();i++){
			System.out.println(trans.get(i));
		} 
		if(trans.size()>0)
			return Optional.of(trans);

		else
			return Optional.empty();		
	}	
}
