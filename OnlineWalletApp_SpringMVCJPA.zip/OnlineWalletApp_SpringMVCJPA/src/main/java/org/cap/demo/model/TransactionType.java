package org.cap.demo.model;


/*----------------Constant data---------------------*/
public enum TransactionType {
	CREDIT,DEBIT;
}
