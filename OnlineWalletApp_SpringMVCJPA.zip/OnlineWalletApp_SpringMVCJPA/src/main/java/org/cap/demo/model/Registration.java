package org.cap.demo.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Past;

import org.cap.demo.validation.ContactNo;
import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Registration {
	
	@Id
	@GeneratedValue
	private int RegistrationId;
	
	@NotEmpty(message = "*please enter firstname")
	private String firstName;
	private String lastName;
	
	@Transient
	private Address address;
		
//	@NotEmpty(message = "*please enter address")
//	private String address;
//	private String city;
//	private String state;
//	
//	@DateTimeFormat(pattern = "MM/dd/yyyy",iso = DateTimeFormat.ISO.DATE)
//	@Past(message = "* Birth date must be a past date.")
//	private LocalDate birthOfDate;
//	
//	@Length(min=6,max=6,message = "* Pincode must be 6 digits.")
//	private String pincode;
	
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public void setRegistrationId(int registrationId) {
		this.RegistrationId = registrationId;
	}

	@Email(message ="* Please enter valid email.")
	@NotEmpty(message = "* Please enter email.")
	@Column(unique = true)
	private String emailId;
	
	//@Length(min=1,max=10,message = "* Contact number must be 10 digit.")
	@ContactNo(message = "* Contact no. must be 10 digit.")
	private String contactNo;
	
	@Length(min=6,max=8,message = "* Password length should be minimum 6 and maximumu 8.")
	private String password;
	
	@Transient
	private String confirmPassword;
	
	@OneToMany(targetEntity = Account.class,mappedBy = "registration")
	private List<Account> accounts=new ArrayList<Account>();
	
	

	/*-------------------------------Constructor--------------------------------------------*/

	public Registration(String emailId, String password) {
		super();
		this.emailId = emailId;
		this.password = password;
	}
	
	public Registration() {
	}
	
	public Registration(int registrationId, @NotEmpty(message = "*please enter firstname") String firstName,
			String lastName, Address address,
			@Email(message = "* Please enter valid email.") @NotEmpty(message = "* Please enter email.") String emailId,
			String contactNo,
			@Length(min = 6, max = 8, message = "* Password length should be minimum 6 and maximumu 8.") String password,
			String confirmPassword, String gender) {
		super();
		this.RegistrationId = registrationId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.emailId = emailId;
		this.contactNo = contactNo;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.gender = gender;
	}
	
	
	
	/*-------------------------------getter & setter-------------------------------------------*/
	
	private String gender;
	public int getRegistrationId() {
		return RegistrationId;
	}
	public void setRegisttrationId(int registrationId) {
		this.RegistrationId = registrationId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	
	
	/*-------------------------------toString() method--------------------------------------------*/

	@Override
	public String toString() {
		return "Registration [registrationId=" + RegistrationId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", emailId=" + emailId + ", contactNo=" + contactNo + ", password="
				+ password + ", confirmPassword=" + confirmPassword + ", gender=" + gender + "]";
	}
	

}
