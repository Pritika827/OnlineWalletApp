package org.cap.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@SequenceGenerator(initialValue = 100,sequenceName = "addressSeq",name = "addressSeq")
@Entity
public class Address {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "addressSeq")
	private int addressId; //pk
	private String address; 
	private String city;
	private String state;
	private String pincode;
	
	@OneToOne
	@JoinColumn(name = "registration_fk")
	private Registration registration;
	
	
	/*-------------------------------Constructor--------------------------------------------*/

	public Address() {	
	}
	
	public Address(int addressId, String address, String city, String state, String pincode,
			Registration registration) {
		super();
		this.addressId = addressId;
		this.address = address;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
		this.registration = registration;
	}
	
	/*-------------------------------getter & setter--------------------------------------------*/

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getPincode() {
		return pincode;
	}


	public void setPincode(String pincode) {
		this.pincode = pincode;
	}


	public Registration getRegistration() {
		return registration;
	}


	public void setRegistration(Registration registration) {
		this.registration = registration;
	}


	

	/*-------------------------------toString() method--------------------------------------------*/

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", address=" + address + ", city=" + city + ", state=" + state
				+ ", pincode=" + pincode + ", registration=" + registration + "]";
	}
	

}
