package org.cap.demo.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.cap.demo.model.Account;
import org.cap.demo.model.AccountType;
import org.cap.demo.model.Address;
import org.cap.demo.model.Registration;
import org.cap.demo.model.Transaction;
import org.cap.demo.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

@SessionAttributes({"registrationId","userName"})
@Controller
@RequestMapping("/user")
public class UserController {

	/*@Autowired -- automatically injects the dependent beans into the associated references of a POJO class. */
	@Autowired
	private IUserService userService;


	/*---------------------LOGOUT---------------------*/
	@RequestMapping("/logout")
	public String logoutPage(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	
	
	/*------------------------Registration------------------------------*/
	@RequestMapping("/register")
	public ModelAndView getRegisterPage() {
		return new ModelAndView("register","registration",new Registration());
	}

	@RequestMapping(value="/registerUser",method= RequestMethod.POST)
	public String saveRegistration(
			@Valid @ModelAttribute("registration")Registration registration, BindingResult result) {
		if(result.hasErrors()) {
			return "register";
		}else {		
			registration.getAddress().setRegistration(registration);
			Optional<Registration> registration1= userService.saveRegistration(registration, registration.getAddress());
			System.out.print(registration1.get());
			return "redirect:/";
		}
	}
	

	/*---------------------------login------------------------------------------*/	
	@RequestMapping(value="/ValidateLogin",method=RequestMethod.POST)
	public ModelAndView validateUserLogin(@RequestParam("userEmail")String userEmail,
			@RequestParam("userPwd")String userPwd,HttpSession session) {

		ModelAndView modelAndView = new ModelAndView();
		Registration registration =  new Registration();
		registration.setEmailId(userEmail);
		registration.setPassword(userPwd);
		Optional<Registration> optional = userService.validateUserLogin(registration);
		if(!optional.isEmpty())
		{
			modelAndView.addObject("firstName",optional.get().getFirstName());
			modelAndView.addObject("lastName",optional.get().getLastName());
			modelAndView.addObject("registrationId", optional.get().getRegistrationId());
			session.setAttribute("emailId",optional.get().getEmailId());
			session.setAttribute("registrationId",optional.get().getRegistrationId());

			modelAndView.setViewName("success");
		}else{
			modelAndView.setViewName("redirect:/");
		}
		return modelAndView;
	}


	/*-------------------------------create account----------------------------------------*/
	@RequestMapping("/CreateAccountPage")
	public ModelAndView getcreateAccpage(ModelMap map,HttpSession session) {
		String emailId=session.getAttribute("emailId").toString();
		String registrationId=session.getAttribute("registrationId").toString();
		map.addAttribute("emailId", emailId);
		map.addAttribute("registrationId", registrationId);
		ModelAndView modelAndView = new ModelAndView();

		modelAndView.setViewName("createAcc");
		return modelAndView;
	}

	@RequestMapping(value = "/createAccount",method = RequestMethod.POST)
	public ModelAndView createAccount(@RequestParam("registrationId") int regId,
			@RequestParam("atype") String atype,@RequestParam("balance")double balance,
			@RequestParam("description") String description) {
		ModelAndView modelAndView = new ModelAndView();
		Registration registration = new Registration();
		registration.setRegistrationId(regId);



		Account account = new Account(AccountType.valueOf(atype),LocalDate.now(),balance,description,registration);
		Optional<Account> optional= userService.createAccount(account);
		modelAndView.setViewName("success");		 
		return modelAndView;
	}
	
	
/*-------------------------Deposit in wallet----------------------------------*/
	@RequestMapping("/depositMoneypage")
	public ModelAndView depositWithdrawMoneyPage(ModelMap map,HttpSession session) {
		String emailId=session.getAttribute("emailId").toString();
		String registrationId=session.getAttribute("registrationId").toString();

		map.addAttribute("emailId", emailId);
		map.addAttribute("registrationId", registrationId);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("deposite");
		return modelAndView;
	}

	@RequestMapping(value = "/DepositeAmtFunc", method = RequestMethod.POST)
	public ModelAndView depositeAmt(@RequestParam("registrationId") int registrationId, @RequestParam("atype") String atype,
			@RequestParam("balance") double balance,
			@RequestParam("tType") String tType, HttpSession session) {

		ModelAndView modelAndView = new ModelAndView();
		Registration registration = new Registration();
		registration.setRegistrationId(registrationId);
		Account account = new Account();
		account.setCustomer(registration);

		account.setAccountType(AccountType.valueOf(atype));

		System.out.println( account.getAccountType());
		System.out.println("Deposite Method");

		Optional<Account> optional = userService.depositAmount(account, balance);		

		if (!optional.isEmpty()) {
			modelAndView.setViewName("deposite");
			return modelAndView;
		}
		else {
			modelAndView.setViewName("redirect:/");
			return modelAndView;
		}
	}

	
/*--------------------------------withdraw amount------------------------------*/
	@RequestMapping("/WithdrawMoneypage")
	public ModelAndView WithdrawMoneyPage(ModelMap map,HttpSession session) {
		String emailId=session.getAttribute("emailId").toString();
		String registrationId=session.getAttribute("registrationId").toString();

		map.addAttribute("emailId", emailId);
		map.addAttribute("registrationId", registrationId);
		ModelAndView modelAndView = new ModelAndView();

		modelAndView.setViewName("Withdraw");
		return modelAndView;
	}

	@RequestMapping(value = "/WithdrawAmtFunc", method = RequestMethod.POST)
	public ModelAndView WithdrawAmt(ModelMap map,@RequestParam("registrationId") int registrationId, @RequestParam("atype") String atype,
			@RequestParam("balance") double balance,
			@RequestParam("tType") String tType, HttpSession session) {

		ModelAndView modelAndView = new ModelAndView();
		Registration registration = new Registration();
		registration.setRegistrationId(registrationId);

		System.out.println(registrationId);

		Account account = new Account();
		account.setCustomer(registration);

		account.setAccountType(AccountType.valueOf(atype));

		System.out.println( account.getAccountType());
		System.out.println("Withdraw Method");

		Optional<Account> optional = userService.withdrawAmount(account, balance);		

		if (!optional.isEmpty()) {
			modelAndView.setViewName("Withdraw");
			return modelAndView;
		}else {
			//	String msg = " Insufficient Balance ";
			//	map.addAttribute("error", msg);

			modelAndView.setViewName("WithdrawErr");
			return modelAndView;
		}
	}
	
	
	/*---------------------transfer amount ----------------------------------*/
	@RequestMapping("/transferMoneyPage")
	public ModelAndView gettransferMoneyPage(ModelMap map, HttpSession session) {
		String emailId=session.getAttribute("emailId").toString();
		String registrationId=session.getAttribute("registrationId").toString();

		map.addAttribute("emailId", emailId);
		map.addAttribute("registrationId", registrationId);
		ModelAndView modelAndView = new ModelAndView();


		modelAndView.setViewName("Transfer");
		return modelAndView;
	}

	@RequestMapping("/TransferAmtFunc")
	public ModelAndView transferAmt(ModelMap map,@RequestParam("registrationId") int registrationId, @RequestParam("atype") String atype,
			@RequestParam("amount") double amount, @RequestParam("receiverAc") int receiverAc, HttpSession session) {
		System.out.println("Called Transfer Amount method");
		ModelAndView modelAndView = new ModelAndView();
		Registration registration = new  Registration();
		registration.setRegistrationId(registrationId);
		Account account = new Account();
		account.setCustomer(registration);

		account.setAccountType(AccountType.valueOf(atype));
		System.out.println(account.getAccountType());
		//	System.out.println("Calling transfer ------");

		Optional<Account> optional = userService.transferAmount(account, amount, receiverAc);
		if (!optional.isEmpty()) {
			String msg = " Transferred Successfully!";
			map.addAttribute("error", msg);
			modelAndView.setViewName("Transfer");
			return modelAndView;
		}
		else {
			String msg = " Insufficient Balance ";
			map.addAttribute("error", msg);
			modelAndView.setViewName("Transfer");
			return modelAndView;
		}
	}

	
/*-----------------------------------show transaction-------------------------------*/
	@RequestMapping("/TransactionPage")
	public String TPage() {
		return "transactionDetail";
	}

	@RequestMapping(value = "/transactionDetails", method = RequestMethod.POST)
	public ModelAndView transactionDetails(ModelMap map,HttpSession session,
			@RequestParam("registrationId") int registrationId, @RequestParam("atype") String atype){
		ModelAndView modelAndView = new ModelAndView();
		Account account = new Account();
		Registration registration = new Registration();
		registration.setRegistrationId(registrationId);
		account.setCustomer(registration);

		account.setAccountType(AccountType.valueOf(atype));
		Optional<List<Transaction>>  optional = userService.transactionDetails(account);
		System.out.println(optional.get());

		if (!optional.isEmpty()) {
			map.addAttribute("transactions", optional.get());
			modelAndView.setViewName("Tlist");
			return modelAndView;
		}
		else {
			modelAndView.setViewName("transactionDetail");
			return modelAndView;
		}
	}
	
	
	/*------------------------show transaction according to date -------------------*/
	@RequestMapping("/TransactionDatePage")
	public String TDPage() {
		return "TransactionSearch";
	}

	@RequestMapping(value = "/transactionPD", method = RequestMethod.POST)
	public ModelAndView transactionPD(ModelMap map,HttpSession session,
			@RequestParam("registrationId") int registrationId, @RequestParam("atype") String atype, 
			@RequestParam("start_date") String start_date,@RequestParam("end_date") String end_date){
		ModelAndView modelAndView = new ModelAndView();
		Account account = new Account();

		Registration registration=new Registration();
		registration.setRegistrationId(registrationId);
		account.setCustomer(registration);

		account.setAccountType(AccountType.valueOf(atype));
		Optional<List<Transaction>>  optional = userService.transactionParticularDate(account, start_date,end_date);
		System.out.println(optional.get());

		if (!optional.isEmpty()) {
			map.addAttribute("transactions", optional.get());
			modelAndView.setViewName("Tlist");
			return modelAndView;
		}
		else {
			modelAndView.setViewName("TransactionSearch");
			return modelAndView;
		}
	}

}







