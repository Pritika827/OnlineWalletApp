function createAccountValidation(){
	
	var balance=createAcc.balance.value
		
	if(balance=="" || balance==null ){
		
		document.getElementById("errBal").innerHTML='Please enter account openning balance more than 1000!'
		createAcc.balance.focus()
		return false
	
		}
		else{
			document.getElementById("errBal").innerHTML=''
		}	
		}